package Entity;

import java.awt.Rectangle;

import Main.GamePainel;
import TileMap.Tile;
import TileMap.TileMap;

public abstract class MapObject {
	
	//tile stuffs
	protected TileMap tileMap;
	protected int tileSize;
	protected double xmap;
	protected double ymap;
	
	//position and vector
	protected double x;
	protected double y;
	protected double dx;
	protected double dy;
	
	//dimensions
	protected int width;
	protected int heigth;
	
	//collision box
	protected int cwidth;
	protected int cheigth;
	
	//collision 
	protected int currRow;
	protected int currCol;
	protected double xdest;
	protected double ydest;
	protected double xtemp;
	protected double ytemp;
	protected boolean topLeft;
	protected boolean topRight;
	protected boolean bottomLeft;
	protected boolean bottomRight;
	
	//animation
	protected Animation animation;
	protected int currentAction;
	protected int previousAction;
	protected boolean facingRight;
	
	//movement
	protected boolean left;
	protected boolean right;
	protected boolean up;
	protected boolean down;
	protected boolean jumping;
	protected boolean falling;
	
	//movements attributes
	protected double moveSpeed;
	protected double maxSpeed;
	protected double stopSpeed;
	protected double fallSpeed;
	protected double maxFallSpeed;
	protected double jumpStart;
	protected double stopJumpSpeed;
	
	//constructor
	public MapObject(TileMap tm){
		tileMap = tm;
		tileSize = tm.getTitleSize();
	}
	
	public boolean intersects(MapObject o){
		Rectangle r1 = getRectangle();
		Rectangle r2 = o.getRectangle();
		return r1.intersects(r2);
		
	}
	public Rectangle getRectangle(){
		return new Rectangle((int)x - cwidth, (int)y - cheigth, cwidth, cheigth);
	}
	
	public void calculateCorners(double x, double y){
		
		int leftTile = (int)(x - cwidth / 2) / tileSize;
		int rightTile = (int)(x + cwidth / 2 -1) / tileSize;
		int topTile = (int)(y - cheigth / 2) / tileSize;
		int bottomTile = (int)(y + cheigth / 2 - 1) / tileSize;
		
		if (topTile < 0 || bottomTile >= tileMap.getNumRows() || leftTile < 0 || rightTile >= tileMap.getNumCols()) {
			topLeft = topRight = bottomLeft = bottomRight = false;
			return;
		}
		
		int tL = tileMap.getType(topTile, leftTile);
		int	tR = tileMap.getType(topTile, rightTile);
		int bL = tileMap.getType(bottomTile, leftTile);
		int	bR = tileMap.getType(bottomTile, rightTile);
		
		topLeft = tL == Tile.BLOCKED;
		topRight = tR == Tile.BLOCKED;
		bottomLeft = bL == Tile.BLOCKED;
		bottomRight = bR == Tile.BLOCKED;
		
	}
	
	public void checkTileMapCollision(){
		
		currCol = (int) x / tileSize;
		currRow = (int) y / tileSize;
		
		xdest = x + dx;
		ydest = y + dy;
		
		xtemp = x;
		ytemp = y;
		
		calculateCorners(x, ydest);
		if (dy < 0) {
			if (topLeft || topRight) {
				dy = 0;
				ytemp = currRow * tileSize + cheigth / 2;
			}else {
				ytemp += dy;
			}
		}
		if (dy > 0) {
			if (bottomLeft || bottomRight) {
				dy = 0;
				falling = false;
				ytemp = (currRow + 1) * tileSize - cheigth / 2;
			}else {
				ytemp += dy;
			}
		}
		
		calculateCorners(y, xdest);
		if (dx < 0) {
			if (topLeft || bottomLeft) {
				dx = 0;
				dx = currCol * tileSize + cwidth / 2;
			}else {
				xtemp += dx;
			}
		}
		if (dx > 0) {
			if (topRight || bottomRight) {
				dx = 0;
				dx = (currCol + 1) * tileSize - cwidth / 2;
			}else {
				xtemp += dx;
			}
		}
		
		if (!falling) {
			calculateCorners(x, ydest + 1);
			if (!bottomLeft && !bottomRight) {
				falling = true;
			}
		}
	}
	
	public int getX() {
		return (int)x;
	}
	public int getY() {
		return (int)y;
	}
	public int getWidth() {
		return width;
	}
	public int getHeight() {
		return heigth;
	}
	public int getCWidth() {
		return cwidth;
	}
	public int getCHeight() {
		return cheigth;
	}
	
	public void setPosition(double x, double y) {
		this.x = x;
		this.y = y;
	}
	public void setVectors(double dx, double dy) {
		this.dx = dx;
		this.dy = dy;
	}
	
	public void setMapPosition() {
		xmap = tileMap.getx();
		ymap = tileMap.gety();
	}
	
	public void setLeft(boolean b) {
		left = b;
	}
	public void setRight(boolean b) {
		right = b;
	}
	public void setUp(boolean b) {
		up = b;
	}
	public void setDown(boolean b) {
		down = b;
	}
	public void setJumping(boolean b) {
		jumping = b;
	}
	
	public boolean notOnScreen() {
		return x + xmap + width < 0 || x + xmap - width > GamePainel.WIDTH ||
				y + ymap + heigth < 0 || y + ymap - heigth > GamePainel.HEIGHT;
	}
	
	
	
	
	
	
	
	
}
