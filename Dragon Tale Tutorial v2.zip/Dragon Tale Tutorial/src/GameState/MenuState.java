package GameState;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;
import TileMap.BackGround;

public class MenuState extends GameState {
	private BackGround backGround;
	private int currentChoise = 0;
	public String[] options = {
			"Start",
			"Help",
			"Quit"
	};
		
	private Color colorTitle;
	private Font fontTitle;
	private Font font;
	
	
	public MenuState(GameStateManager gameStateManager){
		this.gameStateManager = gameStateManager;
		
		try {
			
			backGround = new BackGround("/Backgrounds/menubg.gif", 1);
			backGround.setVector(-0.1, 0);
			
			colorTitle = new Color(128,0,0);
			fontTitle = new Font("Century Gothic", Font.PLAIN, 28);
			font = new Font("Arial", Font.PLAIN, 12);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void init(){
		
	}
	
	public void update(){
		backGround.update();
	}
	
	public void draw(Graphics2D graphics2d){
		//draw bg
		backGround.draw(graphics2d);
		//draw title
		graphics2d.setColor(colorTitle);
		graphics2d.setFont(fontTitle);
		graphics2d.drawString("Dragon Tale", 80, 70);
		//draw options
		graphics2d.setFont(font);
		for(int i = 0; i < options.length; i++){
			if(i == currentChoise){
				graphics2d.setColor(Color.black);
			}else{
				graphics2d.setColor(Color.red);
			}
			graphics2d.drawString(options[i], 145, 140 + i * 15);
		}
	}
	
	public void keyPressed(int k){
		switch (k) {
		case KeyEvent.VK_ENTER:
			select();
		case KeyEvent.VK_UP:
			currentChoise--;
			if(currentChoise == -1){
				currentChoise = options.length -1;
			}
		case KeyEvent.VK_DOWN:
			currentChoise++;
			if(currentChoise == options.length){
				currentChoise = 0;
			}
		}
		
		
	}
	private void select(){
		switch (currentChoise) {
		case 0:
			gameStateManager.setState(gameStateManager.LEVEL1STATE);
			
			break;
		case 1:
			//help
			
			break;
		case 2:
			//quit
			System.exit(0);
			break;

		default:
			break;
		}
	}	
	public void keyReleased(int k){
	}

	@Override
	public void keyRelease(int k) {
		// TODO Auto-generated method stub
		
	}

}
