package GameState;

import TileMap.*;

import java.awt.Graphics2D;

public class Level1State extends GameState {

	private TileMap tileMap;
	private BackGround bg;
	
	public Level1State(GameStateManager gameStateManager){
		this.gameStateManager = gameStateManager;
		init();
	}
	
	public void init(){
		tileMap = new TileMap(30);
		tileMap.loadTiles("/Tilesets/grasstileset.gif");
		tileMap.loadMap("/Maps/level1-1.map");
		tileMap.setPosition(0, 0);
		bg = new BackGround("/Backgounds/grassbg1.gif", 0.1);
		
	}
	
	public void update(){
		
	}
	
	public void draw(Graphics2D graphics2d){
		//draw bg
		bg.draw(graphics2d);
		
		//draw TileMap
		tileMap.draw(graphics2d);
	}
	
	public void keyPressed(int k){
		
	}
	public void keyReleased(int k){
		
	}

	@Override
	public void keyRelease(int k) {
		// TODO Auto-generated method stub
		
	}
}
