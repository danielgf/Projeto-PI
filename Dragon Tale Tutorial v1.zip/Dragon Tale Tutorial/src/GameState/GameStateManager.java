package GameState;

import java.util.ArrayList;

public class GameStateManager {
	
	private ArrayList<GameState> gameState;
	private int currentState;
	private final int menuState = 0;
	private final int leval1State = 1;
	
	public GameStateManager() {
		gameState = new ArrayList<GameState>();
		currentState = menuState;
		gameState.add(new MenuState(this));
	}
	
	public void setState(int state){
		currentState = state;
		 gameState.get(currentState).init();	 
	}
	
	public void update(){
		gameState.get(currentState).update();
	}
	
	public void draw(java.awt.Graphics2D graphics2d){
		gameState.get(currentState).draw(graphics2d);
	}
	
	public void keyPressed(int k){
		gameState.get(currentState).keyPressed(k);
	}
	public void keyReleased(int k){
		gameState.get(currentState).keyRelease(k);
	}
}
