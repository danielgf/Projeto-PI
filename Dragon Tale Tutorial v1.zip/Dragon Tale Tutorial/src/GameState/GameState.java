package GameState;

public abstract class GameState {
	
	protected GameStateManager gameStateManager;
	
	public abstract void init();
	public abstract void update();
	public abstract void draw(java.awt.Graphics2D graphics2d);
	public abstract void keyPressed(int k);
	public abstract void keyRelease(int k);
}
